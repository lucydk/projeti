import Empregados from './empregados';

export default function App() {
  return (
    <div>
      <h1>Funcionários</h1>
      <Empregados />
    </div>
  );
}
