import axios from 'axios';

export default axios.create({
  baseURL: 'https://api-teste.tcc.uniuv.edu.br/api'
});
