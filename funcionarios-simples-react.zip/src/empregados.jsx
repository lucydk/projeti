import { useEffect, useState } from 'react';
import api from './api';

export default function Empregados() {
  const [lista, setLista] = useState([]);

  useEffect(() => {
    api.get('/employees')
      .then(res => setLista(res.data))
      .catch(err => console.log(err));
  }, []);

  return (
    <div>
      {lista.map(emp => (
        <div key={emp.id}>
          <p>ID: {emp.id}</p>
          <p>Nome: {emp.name}</p>
          <p>Salário: {emp.salary}</p>
          <p>Bônus: {emp.bonus}</p>
          <hr />
        </div>
      ))}
    </div>
  );
}
